package model;

public class Task {
    //Declares variables required for task script
    private ListType taskList;
    private ADTDate deadline;
    private String task;
    private TeamMember teamMemberAssigned;
    private String comments;
    private String tags;

    public Task() {//Sets the different variables a task can have; deadline, assigned member etc.
        this.taskList = ListType.TODO;
        this.deadline = new ADTDate();
        this.task = "";
        this.teamMemberAssigned = new TeamMember();
        this.comments = "";
        this.tags = "";
    }
    //Getters and setters for the task script
    public ListType getTheListType() {
        return this.taskList;
    }

    public void setTheListType(ListType theListType) {this.taskList = theListType; } //Sets the list type, to do, doing, or done

    public ADTDate getDeadline() {
        return this.deadline;
    } //Retrieves the deadline for a task

    public void setDeadline(ADTDate aDueDate) {
        this.deadline = aDueDate;
    } //Sets the deadline for a task

    public String getTask() {
        return this.task;
    } //Retreives the task title

    public void setTask(String aTask) {
        this.task = aTask;
    } //Sets the task title

    public TeamMember getAllocatedTeamMember() {return this.teamMemberAssigned;} //Retrieves the team member assigned to the task

    public void setAllocatedTeamMember(TeamMember allocatedToTM) {
        this.teamMemberAssigned = allocatedToTM;
    } //Sets the assigned team member

    public String getComments() {
        return this.comments;
    } //Retrieves the task's comments

    public void setComments(String theTaskComments) {
        this.comments = theTaskComments;
    } //Sets the tasks comments

    public String getTags() {
        return this.tags;
    } //Retrieves the task's tags

    public void setTags(String taskTags) {
        this.tags = taskTags;
    } //Sets the task's tags

    public String CSVFormat() { //Converts the user's input into CSV format
        String outputStr = ListType.valueOf(this.taskList.toString()) + "," + this.deadline.toString() + "," + this.task + "," + this.teamMemberAssigned.CSVFormat() + "," + this.comments + "," + this.tags;
        return outputStr;
    }

    public String toString() { //Displays the different aspects of a task
        return "Task{theList=" + this.taskList + ", theDueDate=" + this.deadline + ", theTask='" + this.task + '\'' + ", allocatedTo=" + this.teamMemberAssigned.getAllocatedTo() + ", taskComments='" + this.comments + '\'' + ", theTags='" + this.tags + '\'' + '}';
    }
}
