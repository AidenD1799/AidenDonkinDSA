package model;

public class TeamMember {
    //Variables used to store info about team members
    private String forename;
    private String surname;
    private Role projectRole;

    public TeamMember() { //Sets up the team member variables as blank
        this.forename = "";
        this.surname = "";
        this.projectRole = Role.ANALYST;
    }

    public TeamMember(String theForename, String theSurname, Role theProjectRole) { //Method used to assign the different aspects of a team member
        this.forename = theForename;
        this.surname = theSurname;
        this.projectRole = theProjectRole;
    }

    public String getForename() {
        return this.forename;
    } //Retrieves the forename of a team member

    public void setForename(String forename) {
        this.forename = forename;
    } //Sets the forename of a team member

    public String getSurname() {
        return this.surname;
    } //Retrieves the surname of a team member

    public void setSurname(String surname) {
        this.surname = surname;
    } //Sets a surname of a team member

    public Role getProjectRole() {
        return this.projectRole;
    } //Retrieves the project role of a team member

    public void setProjectRole(Role projectRole) {
        this.projectRole = projectRole;
    } //Sets the project role of a team member

    public String getRoleAsString() {
        return this.projectRole.toString();
    } //Retrieves the project role of a team member in string format

    public String getAllocatedTo() {
        return this.forename + " " + this.surname + ", " + this.projectRole.toString();
    }

    public String CSVFormat() { //Converts the team member info into CSV format
        String outputStr = this.forename + "," + this.surname + "," + this.projectRole.toString();
        return outputStr;
    }

    public String toString() {//Displays the team member's info
        return "TeamMember{firstname='" + this.forename + '\'' + ", lastname='" + this.surname + '\'' + ", tmRole=" + this.getRoleAsString() + '}';
    }
}
