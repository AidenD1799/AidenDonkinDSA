package model;

public enum ListType {
    TODO,
    DOING,
    DONE;
}
