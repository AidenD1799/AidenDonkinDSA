package app;

import controllers.controller;

public class ToDoApp {
    //Creates an object of type controller and runs it
    private static void run() {
        final controller controller = new controller();
        controller.run();
    }

    //Starts the application by starting the run method
    public static void main(final String[] args) {
        ToDoApp.run();
    }
}
