package view;

import datastructures.ADTSingleLinkedList;
import datastructures.listNode;
import helpers.OutputHelper;
import java.io.PrintStream;
import model.Task;

public class taskListView {
    public taskListView() {
    }

    public void displayATask(Task aTask) { //Displays a task to the user in an appropriate format using output helpers
        System.out.println(OutputHelper.repeat("-", 90));
        System.out.format("| %-45s | %-25s | %-10s |\n", "Task", "Allocated To", "Due Date");
        System.out.println(OutputHelper.repeat("-", 90));
        System.out.format("| %-45s | %-25s | %-10s |\n", aTask.getTask(), aTask.getAllocatedTeamMember().getAllocatedTo(), aTask.getDeadline().toString());
        System.out.println(OutputHelper.repeat("-", 90));
    }

    public void displayATask(listNode<Task> aTask) { //Displays a task to the user in an appropriate format using output helpers(this method has alternative parameters to the previous method)
        System.out.println(OutputHelper.repeat("-", 90));
        System.out.format("| %-45s | %-25s | %-10s |\n", "Task", "Allocated To", "Due Date");
        System.out.println(OutputHelper.repeat("-", 90));
        System.out.format("| %-45s | %-25s | %-10s |\n", ((Task)aTask.getNodeData()).getTask(), ((Task)aTask.getNodeData()).getAllocatedTeamMember().getAllocatedTo(), ((Task)aTask.getNodeData()).getDeadline().toString());
        System.out.println(OutputHelper.repeat("-", 90));
    }

    public void displayListTasks(ADTSingleLinkedList<Task> listTasks) {//Displays a list of tasks in the appropriate format
        System.out.println(OutputHelper.repeat("-", 96));
        System.out.format("| %-3s | %-45s | %-25s | %-10s |\n", "No.", "Task", "Allocated To", "Due Date");
        System.out.println(OutputHelper.repeat("-", 96));
        int count = 0;

        for(listNode tmp = listTasks.front(); tmp != null; tmp = tmp.getNextNode()) {
            PrintStream var10000 = System.out;
            Object[] var10002 = new Object[4];
            ++count;
            var10002[0] = count;
            var10002[1] = ((Task)tmp.getNodeData()).getTask();
            var10002[2] = ((Task)tmp.getNodeData()).getAllocatedTeamMember().getAllocatedTo();
            var10002[3] = ((Task)tmp.getNodeData()).getDeadline().toString();
            var10000.format("| %-3s | %-45s | %-25s | %-10s |\n", var10002);
        }

        System.out.println(OutputHelper.repeat("-", 96));
    }
}

