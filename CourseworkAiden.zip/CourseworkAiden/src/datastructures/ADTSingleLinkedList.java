package datastructures;

public class ADTSingleLinkedList<E> implements IADTLinkedList<E> {
    private listNode<E> head = null;
    private int listSize = 0;

    public ADTSingleLinkedList() {
    }

    public int length() {
        return this.listSize;
    } //When called displays the length of the list

    public boolean isEmpty() {
        return this.listSize == 0;
    } //Returns true if the list is empty

    public void createList() { //Creates a new list
        this.head = null;
        this.listSize = 0;
    }

    public void printList() { //Prints the contents of a list
        int pos = 0;

        for(listNode node = this.head; node != null; node = node.getNextNode()) {
            ++pos;
            System.out.format("(%d) ==> %s \n", pos, node.getNodeData().toString());
        }

    }

    public listNode<E> front() {
        return this.head;
    } //Returns the variable at the front of the list

    public void insert(E theNode) { //Inserts a new node into the list
        listNode<E> node = new listNode();
        node.setNodeData(theNode);
        node.setNextNode(this.head);
        this.head = node;
        ++this.listSize;
    }

    public void remove(E theNode) { //Removes a node from the list
        listNode<E> previousNode = null;

        for(listNode activeNode = this.head; activeNode != null; activeNode = activeNode.getNextNode()) {
            if (theNode.equals(activeNode.getNodeData())) {
                if (previousNode == null) {
                    this.head = activeNode.getNextNode();
                } else {
                    previousNode.setNextNode(activeNode.getNextNode());
                }

                System.out.println("Removing item from list ...");
                --this.listSize;
            } else {
                previousNode = activeNode;
            }
        }

    }

    public listNode<E> remove(int index) { //A secondary method for removing nodes from list
        listNode<E> lastNode = null;
        listNode<E> activeNode = this.head;
        listNode<E> nodeToReturn = null;
        boolean stop = false;
        int pos = 1;
        if (this.listSize < index) {
            System.out.println("The list does not have a node in that position, it is likely too small ...");
            return null;
        } else {
            while(activeNode != null || !stop) {
                if (index == pos) {
                    if (lastNode == null) {
                        this.head = activeNode.getNextNode();
                    } else {
                        lastNode.setNextNode(activeNode.getNextNode());
                    }

                    System.out.println("Removing item from list ...");
                    stop = true;
                    nodeToReturn = activeNode;
                    --this.listSize;
                } else {
                    lastNode = activeNode;
                }

                activeNode = activeNode.getNextNode();
                ++pos;
            }

            return nodeToReturn;
        }
    }

    public boolean find(E theNode) { //Used to locate a node within the list
        for(listNode node = this.head; node != null; node = node.getNextNode()) {
            if (theNode.equals(node.getNodeData())) {
                return true;
            }
        }

        return false;
    }

    public listNode<E> find(String theLastName) { //A secondary method for locating a node within a list
        listNode<E> node = this.head;

        for(String theData = ""; node != null; node = node.getNextNode()) {
            theData = node.getNodeData().toString();
            String[] tokens = theData.split(",");
            if (theLastName.equals(tokens[2])) {
                return node;
            }
        }

        return null;
    }
}
