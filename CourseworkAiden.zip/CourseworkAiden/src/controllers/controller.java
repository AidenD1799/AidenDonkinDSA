package controllers;

import daos.listDAOImpl;
import helpers.InputHelper;
import helpers.TextColours;
import model.ListType;
import model.Role;
import model.Task;
import model.TeamMember;
import view.taskListView;

public class controller {
    //Creates list DAOS which are used to store task list info
    private final listDAOImpl tasksStillToDoListDAO = new listDAOImpl();
    private final listDAOImpl tasksBeingWorkedOnDAO = new listDAOImpl();
    private final listDAOImpl completedTasksDAO = new listDAOImpl();
    //Creates a variable used to display the task list
    private final taskListView tasksDisplay = new taskListView();
    //Creates an input helper to allow the user to enter choices
    private final InputHelper inputHelper = new InputHelper();

    public controller() {
    }

    public void run() { //Runs the setup method
        this.setup();
        boolean finished = false;
        boolean var2 = false;

        do {
            this.createMenu(); //Runs the menu method which creates the initial display seen by the user
            int userChoice = this.inputHelper.readInt(TextColours.TEXT_GREEN + "Please Select an Option", 8, 1);
            switch(userChoice) { //Switch statement is used to navigate the different options available to the player
                case 1:
                    this.displayTasksToDoList(); //Displays the tasks that are still to be completed
                    System.out.println();
                    break;
                case 2:
                    this.displaysTasksBeingWorkedOnList(); //Displays the tasks that are currently being worked on
                    System.out.println();
                    break;
                case 3:
                    this.displayCompletedTasksList(); //Displays the tasks which have been completed by the group
                    System.out.println();
                    break;
                case 4:
                    this.displayAllTasks(); //Shows every registered task
                    System.out.println();
                    break;
                case 5:
                    this.addNewTask(); //Adds a new task to the list and asks user for task details
                    System.out.println();
                    break;
                case 6:
                    this.changeTaskToDoingList(); //Changes a task to the doing/in progress status
                    System.out.println();
                    break;
                case 7:
                    this.registerCompletedTask(); //Changes a task to the done/completed status
                    System.out.println();
                    break;
                case 8:
                    System.out.println("Exiting Program"); //Exits the program
                    finished = true;
                    break;
                default:
                    System.out.println("An Error has Occurred"); //Prints an error message to the user if they input an unsuitable value
            }
        } while(!finished);

        this.saveDataToFile();
    }

    private void setup() { //Loads the appropriate files which contain task list info
        this.tasksStillToDoListDAO.loadFromFile("toDoList.txt");
        this.tasksBeingWorkedOnDAO.loadFromFile("doingList.txt");
        this.completedTasksDAO.loadFromFile("doneList.txt");
    }

    private void createMenu() { //Creates the visual display for the initial menu
        System.out.println(TextColours.TEXT_GREEN+ "Task Management Program");
        System.out.println(TextColours.TEXT_RESET + "-----------------------");
        System.out.println(TextColours.TEXT_CYAN + "1: View to do task list");
        System.out.println("2: View doing task list");
        System.out.println("3: View done task list");
        System.out.println("4: View all task lists");
        System.out.println("5: Add a task to the to do list");
        System.out.println("6: Move a task from the to do list to the doing list");
        System.out.println("7: Move a task from the doing list to the done list");
        System.out.println("8: Exit Program");
        System.out.println(TextColours.TEXT_RESET + "-----------------------");
        System.out.println();
    }

    private void displayTasksToDoList() { //Reads from the to do list file and prints the info
        System.out.println(TextColours.TEXT_BLUE + "Viewing To Do List");
        System.out.println(TextColours.TEXT_RESET + "------------------");
        this.tasksDisplay.displayListTasks(this.tasksStillToDoListDAO.getTheTaskLL());
    }

    private void displaysTasksBeingWorkedOnList() { //Reads from the doing list and prints the info
        System.out.println(TextColours.TEXT_BLUE + "Viewing Doing List");
        System.out.println(TextColours.TEXT_RESET + "------------------");
        this.tasksDisplay.displayListTasks(this.tasksBeingWorkedOnDAO.getTheTaskLL());
    }

    private void displayCompletedTasksList() { //Reads from the done list and prints the info
        System.out.println(TextColours.TEXT_BLUE + "Viewing Done List");
        System.out.println(TextColours.TEXT_RESET + "------------------");
        this.tasksDisplay.displayListTasks(this.completedTasksDAO.getTheTaskLL());
    }

    private void displayAllTasks() { //Displays all tasks no matter their status
        System.out.println(TextColours.TEXT_BLUE + "All Tasks");
        System.out.println(TextColours.TEXT_RESET + "---------");
        this.displayTasksToDoList();
        this.displaysTasksBeingWorkedOnList();
        this.displayCompletedTasksList();
    }

    private void addNewTask() { //This method is used to recieve details from the user and add a new task to the to do list
        System.out.println(TextColours.TEXT_BLUE + "Add a task to the to do list");
        System.out.println(TextColours.TEXT_RESET + "----------------------------");
        System.out.println(TextColours.TEXT_BLUE + "5: Add a task to the to do list");
        String task = this.inputHelper.readString(TextColours.TEXT_YELLOW + "Please declare a task");
        String deadline = this.inputHelper.readString("Please input a deadline - In the format: dd/mm/yyyy");
        System.out.println("Allocate to a Team Member");
        String forename = this.inputHelper.readString("Please input Team Member Forename");
        String surname = this.inputHelper.readString("Please input Team Member Surname");
        String userRole = this.inputHelper.readString("Please input Team Member Role - Select One: DESIGNER, ANALYST, DEVELOPER");
        String comments = this.inputHelper.readString("Please input any comments relating to the task");
        String tags = this.inputHelper.readString("Please enter any tags, e.g. HTML:CSS: - In the format: word:word");
        Task newTask = new Task();
        newTask.setTask(task);
        newTask.setAllocatedTeamMember(new TeamMember(forename, surname, Role.valueOf(userRole)));
        newTask.setComments(comments);
        newTask.setTags(tags);
        newTask.setDeadline(this.tasksStillToDoListDAO.parseDateInput(deadline));
        this.tasksStillToDoListDAO.add(newTask);
    }

    private void changeTaskToDoingList() { //This method is used to signify that a task is being worked on by a user and changes its status in the lists
        System.out.println(TextColours.TEXT_BLUE + "Move a task from the the to do list to the doing list");
        System.out.println(TextColours.TEXT_RESET + "-----------------------------------------------------");
        this.tasksDisplay.displayListTasks(this.tasksStillToDoListDAO.getTheTaskLL());
        int pos = this.inputHelper.readInt(TextColours.TEXT_YELLOW + "Please input the index value of the task you would like to move");
        Task nodeToMove = this.tasksStillToDoListDAO.removeTask(pos);
        nodeToMove.setTheListType(ListType.DOING);
        this.tasksDisplay.displayATask(nodeToMove);
        System.out.println(TextColours.TEXT_BLUE + "Allocating task to the doing list ...");
        this.tasksBeingWorkedOnDAO.add(nodeToMove);
        this.tasksDisplay.displayListTasks(this.tasksBeingWorkedOnDAO.getTheTaskLL());
    }

    private void registerCompletedTask() { //This method is used to signify that a task has been completed and change its status in the lists
        System.out.println(TextColours.TEXT_BLUE + "Change a task from the the doing list to the done list");
        System.out.println(TextColours.TEXT_RESET + "----------------------------------------------------");
        this.tasksDisplay.displayListTasks(this.tasksBeingWorkedOnDAO.getTheTaskLL());
        int pos = this.inputHelper.readInt(TextColours.TEXT_YELLOW + "Please input the index value of the task you would like to move");
        Task nodeToMove = this.tasksBeingWorkedOnDAO.removeTask(pos);
        nodeToMove.setTheListType(ListType.DONE);
        this.tasksDisplay.displayATask(nodeToMove);
        System.out.println(TextColours.TEXT_BLUE + "Allocating task to the done list ...");
        this.completedTasksDAO.add(nodeToMove);
        this.tasksDisplay.displayListTasks(this.completedTasksDAO.getTheTaskLL());
    }

    private void saveDataToFile() { //This method saves progress made to the appropriate files
        this.tasksStillToDoListDAO.writeToFile(this.tasksStillToDoListDAO.getTheTaskLL(), "toDoList.txt");
        this.tasksBeingWorkedOnDAO.writeToFile(this.tasksBeingWorkedOnDAO.getTheTaskLL(), "doingList.txt");
        this.completedTasksDAO.writeToFile(this.completedTasksDAO.getTheTaskLL(), "doneList.txt");
    }
}
