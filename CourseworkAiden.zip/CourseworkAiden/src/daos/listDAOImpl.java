package daos;

//Imports appropriate scripts
import app.ToDoApp;
import datastructures.ADTSingleLinkedList;
import datastructures.listNode;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ADTDate;
import model.ListType;
import model.Role;
import model.Task;
import model.TeamMember;

public class listDAOImpl extends DAO {
    private ADTSingleLinkedList<Task> theTaskLL;
    public static final char DELIMITER = ',';
    public static final char EOLN = '\n';
    public static final String QUOTE = "\"";
    public static final String USERDIRECTORY = System.getProperty("user.dir");

    private String stripQuotes(String str) {
        return str.substring(1, str.length() - 1);
    }

    public listDAOImpl() {
        this.theTaskLL = new ADTSingleLinkedList();
    }

    public listDAOImpl(ADTSingleLinkedList<Task> theTaskLL) {
        this.theTaskLL = theTaskLL;
    }

    public ADTSingleLinkedList<Task> getTheTaskLL() {
        return this.theTaskLL;
    }

    public void setTheTaskLL(ADTSingleLinkedList<Task> theTaskLL) {
        this.theTaskLL = theTaskLL;
    }

    public void loadFromFile(String filename) {
        String transactionFile = USERDIRECTORY + "\\" + filename;

        try {
            BufferedReader br = new BufferedReader(new FileReader(transactionFile));
            Throwable var4 = null;

            try {
                for(String line = br.readLine(); line != null; line = br.readLine()) {
                    String[] temp = line.split(Character.toString(','));
                    String theList = temp[0];
                    String theDueDate = temp[1];
                    String theTask = temp[2];
                    String allocatedToFirstname = temp[3];
                    String allocatedToLastname = temp[4];
                    String allocatedToRole = temp[5];
                    String taskComments = temp[6];
                    String theTags = temp[7];
                    Task aTask = new Task();
                    aTask.setTheListType(ListType.valueOf(theList));
                    aTask.setDeadline(this.parseDateInput(theDueDate));
                    aTask.setTask(theTask);
                    aTask.setAllocatedTeamMember(new TeamMember(allocatedToFirstname, allocatedToLastname, Role.valueOf(allocatedToRole)));
                    aTask.setComments(taskComments);
                    aTask.setTags(theTags);
                    this.theTaskLL.insert(aTask);
                }

                br.close();
            } catch (Throwable var24) {
                var4 = var24;
                throw var24;
            } finally {
                if (br != null) {
                    if (var4 != null) {
                        try {
                            br.close();
                        } catch (Throwable var23) {
                            var4.addSuppressed(var23);
                        }
                    } else {
                        br.close();
                    }
                }

            }
        } catch (IOException var26) {
            Logger.getLogger(ToDoApp.class.getName()).log(Level.INFO, (String)null, var26);
        }

    }

    public void writeToFile(ADTSingleLinkedList<Task> listItems, String filename) {
        File myFile;
        try {
            myFile = new File(USERDIRECTORY + "\\" + filename);
            if (myFile.exists()) {
                myFile.delete();
                System.out.println("File deleted: " + myFile.getName());
            } else if (myFile.createNewFile()) {
                System.out.println("File created: " + myFile.getName());
            }
        } catch (IOException var6) {
            System.out.println("An error has occurred.");
            var6.printStackTrace();
        }

        try {
            myFile = new File(USERDIRECTORY + "\\" + filename);
            FileWriter myWriter = new FileWriter(myFile.getName());

            for(listNode tmp = this.theTaskLL.front(); tmp != null; tmp = tmp.getNextNode()) {
                if (tmp.getNextNode() == null) {
                    myWriter.write(((Task)tmp.getNodeData()).CSVFormat());
                } else {
                    myWriter.write(((Task)tmp.getNodeData()).CSVFormat() + "\n");
                }
            }

            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException var7) {
            System.out.println("An error has occurred.");
            var7.printStackTrace();
        }

    }

    public void writeCurrentStateToFile() {
    }

    public void add(Task aTask) {
        this.theTaskLL.insert(aTask);
    }

    public Task getTask() {
        return null;
    }

    public Task removeTask(int pos) {
        listNode<Task> aTask = this.theTaskLL.remove(pos);
        Task newTask = new Task();
        newTask.setTask(((Task)aTask.getNodeData()).getTask());
        newTask.setDeadline(this.parseDateInput(((Task)aTask.getNodeData()).getDeadline().toString()));
        newTask.setAllocatedTeamMember(new TeamMember(((Task)aTask.getNodeData()).getAllocatedTeamMember().getForename(), ((Task)aTask.getNodeData()).getAllocatedTeamMember().getSurname(), Role.valueOf(((Task)aTask.getNodeData()).getAllocatedTeamMember().getRoleAsString())));
        newTask.setComments(((Task)aTask.getNodeData()).getComments());
        newTask.setTags(((Task)aTask.getNodeData()).getTags());
        return newTask;
    }

    public TeamMember getTeamMember() {
        return null;
    }

    public ADTDate parseDateInput(String aDate) {
        String delims = "/";
        String[] tokens = aDate.split(delims);
        ADTDate theDate = new ADTDate(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
        LocalDate currentDate = LocalDate.now();
        theDate.setElapsedDays(currentDate.getDayOfMonth(), currentDate.getMonthValue(), currentDate.getYear());
        return theDate;
    }
}
